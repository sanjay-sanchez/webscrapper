from pickle import TRUE
from flask import Flask,render_template,Response,request, send_file,url_for,redirect,make_response
import cv2
import mgenpro
app=Flask(__name__)
options=[]
fil=[]
class val:
    bars=0


@app.route('/')
def index():
    return render_template('index.html')
@app.route('/page1.html')
def page():
    return render_template('page1.html')
@app.route('/MusiqTiles.html')
def TIles():
    return render_template('MusiqTiles.html')
@app.route('/submit',methods=["GET","POST"])
def submit():
    
    if request.method=='POST':
        bars=request.form['bars']
        notes=request.form['notes']
        key=request.form['key']
        scale=request.form['scale']
        scroot=request.form['scroot']
        pop=request.form['pop']
        options.append(bars)
        options.append(notes)
        options.append(key)
        options.append(scale)
        options.append(scroot)
        options.append(pop)

        
        #return redirect(url_for('final'))
        #return bars+' '+notes+' '+key+' '+scale+' '+scroot+' '+pop
        filn=[bars,notes,key,scale,scroot,pop]
       
        return redirect(url_for('fin'))
        

  
@app.route('/fin')
def fin():
    #mgenpro.main(int(bars),int(notes),1,True,key,scale,int(scroot),int(pop),2,0.5,128)
    return render_template('final.html',val=options)

@app.route("/forward/", methods=['POST'])
def move_forward():
    #Moving forward code
    forward_message = "Moving Forward..."
    return render_template('index.html', forward_message=forward_message)


@app.route("/out",methods=['GET', 'POST'])
def out():
    fil.clear()     
    bars=options[0]
    notes=options[1]
    key=options[2]
    scale=options[3]
    scroot=options[4]
    pop=options[5]
    mgenpro.main(int(bars),int(notes),3,False,key,scale,int(scroot),int(pop),2,0.5,180)
    for i in mgenpro.temp:
        filee=str(i)
        fil.append(filee.replace('static/',''))
    #print("before return"+str(fil))
    return render_template('out.html',out=list(fil))
@app.route("/random.html")
def mm():
    return  render_template('random.html')

if __name__=="__main__":
    app.run(debug=True)