from midiutil import MIDIFile

def notes(tonality, track_interval_one, track_interval_two, loop_length, meter, melody_iteration, first_note, root_note, track_name, verbose):
    beats_in_loop = meter*loop_length - 1
    inverse_melody_iteration = melody_iteration

    # Song Settings
    track_tempo = 120
    beat = 0
    process_loop = zeroes(beats_in_loop+1)
    process_interval = track_interval_one


    # Initialise Tonality
    scale = NoteMap(root_note, tonality)
    current_note = int(root_note)
    for i in range(first_note, 0):
        current_note = scale.next_step(current_note)

    # MIDI STUFF
    #
    # some of these fields could be approached at a
    # later date to achieve a more humanised feel (for
    # example velocity) but for now I am lazy
    track_index = 0
    time_index = 0
    track_channel = 0
    track_volume = 100
    note_duration = 1
    track_handle = MIDIFile(1)
    track_handle.addTrackName(track_index, time_index, track_name)
    track_handle.addTempo(track_index, time_index, track_tempo)


    # COMPOSITIONAL LOGIC
    while melody_iteration > 0:
        if process_loop[beat] > 0.0:
            if verbose:
                print switch_string.format(str(melody_iteration), str(beat), str(process_interval), str(process_loop[beat]), str(process_loop[beat]))
            if process_interval == track_interval_one:
                process_interval = track_interval_two
            else:
                process_interval = track_interval_one
        process_loop[beat] += 1
        track_handle.addNote(track_index, track_channel, current_note, beat, note_duration, track_volume)
        current_note = scale.next_step(current_note)
        beat += process_interval
        if beat > beats_in_loop:
            if verbose:
                end_of_loop_string.format(str(beat))
            melody_iteration -= 1
            beat -= beats_in_loop + 1       # The +1 returns the cursor to beat 1 rather than beat 0 (out of bounds)
            if verbose:
                beat_reset_string.format(str(beat))
        if verbose:
            print iteration_string.format(str(inverse_melody_iteration-melody_iteration), str(beat), str(process_loop))

    print 'I made you {!s} \nhttp://jamescarthew.com/notes for more info'.format(track_name)
    # MIDI print
    with open(track_name, 'wb') as bin_file:
        track_handle.writeFile(bin_file)