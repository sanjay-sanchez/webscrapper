let now_playing = document.querySelector(".now-playing");
let track_art = document.querySelector(".track-art");
let track_name = document.querySelector(".track-name");
let track_artist = document.querySelector(".track-artist");
let track_path = document.querySelector(".track-path");


let playpause_btn = document.querySelector(".playpause-track");
let next_btn = document.querySelector(".next-track");
let prev_btn = document.querySelector(".prev-track");

let seek_slider = document.querySelector(".seek_slider");
let volume_slider = document.querySelector(".volume_slider");
let curr_time = document.querySelector(".current-time");
let total_duration = document.querySelector(".total-duration");
let download=document.querySelector(".down")
let track_index = 0;
let isPlaying = false;
let updateTimer;

// Create new audio element
let curr_track = document.createElement('audio');

// Define the tracks that have to be played
let track_list = [
  {
    name: "Night Owl",
    artist: "Broke For Free",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/AJ_Digital_Camera.svg",
    path:  "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/7000$/7000$%20'%d0%9f%d0%be%d0%b7%d0%b4%d0%bd%d0%be'.mp3",
    
  },
  {
    name: "Enthusiast",
    artist: "Tours",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/feedsync.svg",
    path: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Tours/Enthusiast/Tours_-_01_-_Enthusiast.mp3"
  },
  {
    name: "Shipping Lanes",
    artist: "Chad Crouch",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/http.svg",
    path: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Shipping_Lanes.mp3",
  },

  {
    name: "Mixkit",
    artist: "lesfm",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/vnu.svg",
    path: "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/Afrodita/Afrodita%2003.mp3",
  },
  {
    name: "Sad-kingpath",
    artist: "comastudio",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/wikimedia.svg",
    path: "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/Aria/Aria%20'More%20Of%20You'.mp3",
  },
  {
    name: "Ambient",
    artist: "RomanBelov",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/poi.svg",
    path: "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/Aria/Aria%20'Reunion'.mp3",
  },
  {
    name: "calmotaxi",
    artist: "Olexy",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/x11.svg",
    path: "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/Aria/Aria%20'Three%20Faces-Common%20Ground'.mp3",
  },
  {
    name: "cinematic",
    artist: "anton vlasov",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/rfeed.svg",
    path: "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/Avril/Avril%20'Mobile'.mp3",
  },
  {
    name: "watR-Fluid",
    artist: "ItsWatr",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/openweb.svg",
    path: "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/Manu%20Chao/Manu%20Chao%20'Merry%20Blues'.mp3",
  },
  {
    name: "Moment",
    artist: "SergeQuadrado",
    image: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/accessible.svg",
    path: "http://hcmaslov.d-real.sci-nnov.ru/public/mp3/Manu%20Chao/Manu%20Chao%20'Infinita%20Tristeza'.mp3",
  },
];

function random_bg_color() {

  // Get a number between 64 to 256 (for getting lighter colors)
  let red = Math.floor(Math.random() * 256) + 64;
  let green = Math.floor(Math.random() * 256) + 64;
  let blue = Math.floor(Math.random() * 256) + 64;

  // Construct a color withe the given values
  let bgColor = "rgb(" + red + "," + green + "," + blue + ")";

  // Set the background to that color
  document.body.style.background = bgColor;
}
function Down(){
  var iframe = document.getElementById('dwn');
    iframe.href = track_list[track_index].path;
}

function loadTrack(track_index) {
  clearInterval(updateTimer);
  resetValues();
  curr_track.src=track_list[track_index].path;
  curr_track.load();
  const a = document.querySelector('#someId');
  a.href = track_list[track_index].path;

  track_art.style.backgroundImage = "url(" + track_list[track_index].image + ")";
  track_name.textContent = track_list[track_index].name;
  track_artist.textContent = track_list[track_index].artist;
  now_playing.textContent = "PLAYING " + (track_index + 1) + " OF " + track_list.length;

  updateTimer = setInterval(seekUpdate, 1000);
  curr_track.addEventListener("ended", nextTrack);
  random_bg_color();
}


function resetValues() {
  curr_time.textContent = "00:00";
  total_duration.textContent = "00:00";
  seek_slider.value = 0;
}

// Load the first track in the tracklist
loadTrack(track_index);

function playpauseTrack() {
  if (!isPlaying) playTrack();
  else pauseTrack();
}

function playTrack() {
  curr_track.play();
  isPlaying = true;
  playpause_btn.innerHTML = '<i class="fa fa-pause-circle fa-5x"></i>';
}

function pauseTrack() {
  curr_track.pause();
  isPlaying = false;
  playpause_btn.innerHTML = '<i class="fa fa-play-circle fa-5x"></i>';;
}

function nextTrack() {
  if (track_index < track_list.length - 1)
    track_index += 1;
  else track_index = 0;
  loadTrack(track_index);
  playTrack();
}

function prevTrack() {
  if (track_index > 0)
    track_index -= 1;
  else track_index = track_list.length;
  loadTrack(track_index);
  playTrack();
}

function seekTo() {
  let seekto = curr_track.duration * (seek_slider.value / 100);
  curr_track.currentTime = seekto;
}

function setVolume() {
  curr_track.volume = volume_slider.value / 100;
}

function seekUpdate() {
  let seekPosition = 0;

  if (!isNaN(curr_track.duration)) {
    seekPosition = curr_track.currentTime * (100 / curr_track.duration);

    seek_slider.value = seekPosition;

    let currentMinutes = Math.floor(curr_track.currentTime / 60);
    let currentSeconds = Math.floor(curr_track.currentTime - currentMinutes * 60);
    let durationMinutes = Math.floor(curr_track.duration / 60);
    let durationSeconds = Math.floor(curr_track.duration - durationMinutes * 60);

    if (currentSeconds < 10) { currentSeconds = "0" + currentSeconds; }
    if (durationSeconds < 10) { durationSeconds = "0" + durationSeconds; }
    if (currentMinutes < 10) { currentMinutes = "0" + currentMinutes; }
    if (durationMinutes < 10) { durationMinutes = "0" + durationMinutes; }

    curr_time.textContent = currentMinutes + ":" + currentSeconds;
    total_duration.textContent = durationMinutes + ":" + durationSeconds;
  }
}

