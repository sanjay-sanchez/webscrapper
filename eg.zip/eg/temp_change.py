from math import degrees
from midiutil import MIDIFile
import random
seg=[]
degrees=[]
for i in range(90):
    #degrees  = [] # MIDI note number
    degrees.append(random.randint(0,127))
for ii in range(5):
    seg.append(random.randint(50,127))
for run in range(0,10):
    te=random.randint(0,len(degrees))
    for i2 in seg:
        degrees.insert(te,i2)
        te=te+1
# for i in range(4):
#     k=random.randint(4,120)
#     degrees.append(k)
#     degrees.append(k+2)
#     degrees.append(k-2)
# seg=degrees

# # print(degrees)
# for i in range(2):
#     k=random.randint(4,120)
#     degrees.append(k)
#     degrees.append(k+2)
#     #degrees.append(seg)
# degrees=degrees+seg
# # seg2=degrees
# # for i in range(2):
# #     k=random.randint(4,120)
# #     degrees.append(k)
# #     degrees.append(k+2)
# #     degrees.append(seg2)


def changer():
    track    = 0
    t2=1
    channel  = 0
    time     = 3   # In beats
    duration = 3   # In beats
    tempo    = 220  # In BPM
    volume   = 100 # 0-127, as per the MIDI standard
    MyMIDI = MIDIFile(1) # One track, defaults to format 1 (tempo track
                     # automatically created)
    MyMIDI.addTempo(track,time, tempo)
    k=0
    for pitch in degrees:
        MyMIDI.addNote(track, channel, pitch, time, duration, volume)
        # while(k<10):
        #     MyMIDI.addNote(track, channel, k+30, k+2, duration, volume)    
        #     k+=1        
        time = time + 1
    #print('writing into'+k)
    with open('newww.mid', "wb") as output_file:
        MyMIDI.writeFile(output_file)
changer()